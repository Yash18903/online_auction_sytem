import React, { useState, useEffect } from "react";
import BidForm from "./components/BidForm";
import BidList from "./components/BidList";
import { getBids } from "./services/bidService";

// Navbar component with Back to Menu and Reload buttons
function Navbar({ reload, backToMenu, selectedItem }) {
  return (
    <nav className="navbar">
      <h2 id="mit1" className="navbar-title">
        Online Auction Plaform
      </h2>
      <div className="navbar-buttons">
        <button
          className="btn btn-back"
          onClick={backToMenu}
          disabled={!selectedItem}
        >
          Back to Menu
        </button>
        <button className="btn btn-reload" onClick={reload}>
          Reload
        </button>
      </div>
    </nav>
  );
}

function App() {
  const [bids, setBids] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [menuItems, setMenuItems] = useState([
    { id: 1, name: "Mobile" },
    { id: 2, name: "Television" },
    { id: 3, name: "Fridge" },
    { id: 4, name: "Laptop" },
  ]);
  const [newItem, setNewItem] = useState("");

  const fetchBids = async () => {
    const response = await getBids();
    if (response.data.success) {
      setBids(response.data.data);
    }
  };

  useEffect(() => {
    fetchBids();
  }, []);

  const addNewItem = () => {
    if (newItem.trim() !== "") {
      setMenuItems([...menuItems, { id: menuItems.length + 1, name: newItem }]);
      setNewItem("");
    }
  };

  const backToMenu = () => {
    setSelectedItem(null);
  };

  return (
    <div className="app-container">
      <Navbar
        reload={fetchBids}
        backToMenu={backToMenu}
        selectedItem={selectedItem}
      />

      {!selectedItem ? (
        <div className="menu-container">
          <h1 className="menu-title">Products</h1>
          <div className="menu-grid">
            {menuItems.map((item) => (
              <div
                key={item.id}
                className="menu-item"
                onClick={() => setSelectedItem(item)}
              >
                {item.name}
              </div>
            ))}
          </div>
          <div className="new-item-container">
            <input
              type="text"
              placeholder="Enter new item"
              value={newItem}
              onChange={(e) => setNewItem(e.target.value)}
              className="new-item-input"
            />
            <button className="btn btn-add" onClick={addNewItem}>
              Add Item
            </button>
          </div>
        </div>
      ) : (
        <div className="bid-container">
          <h2 className="bid-title">Bidding for {selectedItem.name}</h2>
          <BidForm fetchBids={fetchBids} selectedItem={selectedItem} />
          <BidList
            bids={bids}
            fetchBids={fetchBids}
            selectedItem={selectedItem}
          />
        </div>
      )}

      <style>{`

      #mit1{
      color:white;
      }
        /* Global Styles & Money-themed Background */
        body {
          margin: 0;
          padding: 0;
          font-family: 'Roboto', sans-serif;
          background-image: url('https://source.unsplash.com/1600x900/?money');
          background-size: cover;
          background-attachment: fixed;
          background-position: center;
        }

        /* Main App Container with Translucent Overlay */
        .app-container {
          background-color: rgba(255, 255, 255, 0.93);
          margin: 50px auto;
          padding: 30px 40px;
          border-radius: 12px;
          max-width: 900px;
          box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
          backdrop-filter: blur(5px);
        }

        /* Navbar Styles */
        .navbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 8px 15px;
          background: rgba(51, 51, 51, 0.9);
          color: white;
          border-radius: 6px;
          margin-bottom: 20px;
        }

        .navbar-title {
          font-size: 20px;
          margin: 0;
        }

        .navbar-buttons .btn {
          padding: 6px 10px;
          margin-right: 10px;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 14px;
        }

        .btn-back {
          background: #ff9800;
          color: white;
        }

        .btn-back:disabled {
          background: #777;
          cursor: not-allowed;
        }

        .btn-reload {
          background: #ff9800;
          color: white;
        }

        /* Menu Styles */
        .menu-container {
          text-align: center;
        }

        .menu-title {
          margin-bottom: 20px;
        }

        .menu-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 10px;
        }

        /* Attractive Cards with Consistent Colour Scheme */
        .menu-item {
          border: 1px solidrgb(145, 167, 146);
          padding: 20px;
          text-align: center;
          cursor: pointer;
          border-radius: 8px;
          background:rgb(212, 234, 236);
          color: #333;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .menu-item:hover {
          transform: translateY(-3px);
          box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .new-item-container {
          margin-top: 20px;
          text-align: center;
        }

        .new-item-input {
          padding: 8px;
          margin-right: 10px;
          border-radius: 4px;
          border: 1px solid #ccc;
        }

        .btn-add {
          padding: 8px;
          border-radius: 4px;
          border: none;
          background: #4caf50;
          color: white;
          cursor: pointer;
        }

        /* Bid Section Styles */
        .bid-container {
          text-align: center;
        }

        .bid-title {
          margin-bottom: 20px;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
          .menu-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 480px) {
          .menu-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}

export default App;
