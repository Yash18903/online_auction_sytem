import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom";

// Dummy getBids service function simulating an API call
const getBids = async () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        data: {
          success: true,
          data: [
            { id: 1, bid: "Bid 1 for item" },
            { id: 2, bid: "Bid 2 for item" },
          ]
        }
      });
    }, 500);
  });
};

// Navbar component with a refresh button that triggers fetchBids
function Navbar({ refresh }) {
  return (
    <nav className="navbar">
      <div className="navbar-logo">Bid App</div>
      <ul className="navbar-menu">
        <li onClick={refresh} className="navbar-refresh">Refresh</li>
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
      </ul>
    </nav>
  );
}

// BidForm component (a simple form for demonstration)
function BidForm({ fetchBids, selectedItem }) {
  const [bid, setBid] = useState("");
  
  const handleSubmit = (e) => {
    e.preventDefault();
    // Simulate bid submission
    console.log(`Submitting bid "${bid}" for ${selectedItem.name}`);
    setBid("");
    fetchBids(); // Refresh bids after "submission"
  };

  return (
    <form onSubmit={handleSubmit} className="bid-form">
      <input 
        type="text" 
        placeholder={`Enter bid for ${selectedItem.name}`} 
        value={bid} 
        onChange={(e) => setBid(e.target.value)}
        className="bid-input"
      />
      <button type="submit" className="bid-button">Submit Bid</button>
    </form>
  );
}

// BidList component (displays a list of bids)
function BidList({ bids, selectedItem }) {
  return (
    <div className="bid-list">
      <h3>Bid List for {selectedItem.name}</h3>
      <ul>
        {bids.map((bid) => (
          <li key={bid.id} className="bid-item">{bid.bid}</li>
        ))}
      </ul>
    </div>
  );
}

// Main App component
function App() {
  const [bids, setBids] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [menuItems, setMenuItems] = useState([
    { id: 1, name: "Mobile" },
    { id: 2, name: "Television" },
    { id: 3, name: "Fridge" },
    { id: 4, name: "Laptop" },
  ]);
  const [newItem, setNewItem] = useState("");

  const fetchBids = async () => {
    const response = await getBids();
    if (response.data.success) {
      setBids(response.data.data);
    }
  };

  useEffect(() => {
    fetchBids();
  }, []);

  const addNewItem = () => {
    if (newItem.trim() !== "") {
      setMenuItems([...menuItems, { id: menuItems.length + 1, name: newItem }]);
      setNewItem("");
    }
  };

  // Inject combined CSS styles into the document head
  useEffect(() => {
    const style = document.createElement("style");
    style.innerHTML = `
      /* Global Styles */
      .app-container {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f5f7fa;
        min-height: 100vh;
      }
      .content-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
      }
      /* Navbar Styles */
      .navbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background-color: #2c3e50;
        padding: 10px 20px;
        color: #fff;
      }
      .navbar-logo {
        font-size: 24px;
        font-weight: bold;
      }
      .navbar-menu {
        list-style: none;
        display: flex;
        gap: 20px;
        margin: 0;
        padding: 0;
      }
      .navbar-menu li {
        cursor: pointer;
        transition: color 0.3s ease;
      }
      .navbar-menu li:hover {
        color: #f39c12;
      }
      .navbar-refresh {
        font-weight: bold;
      }
      /* Page Titles */
      .page-title {
        text-align: center;
        margin-bottom: 20px;
        color: #333;
      }
      /* Menu Grid */
      .menu-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
        gap: 20px;
      }
      .menu-item-card {
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 20px;
        text-align: center;
        cursor: pointer;
        transition: box-shadow 0.3s ease, transform 0.2s ease;
      }
      .menu-item-card:hover {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transform: translateY(-2px);
      }
      /* New Item Input */
      .new-item-container {
        margin-top: 30px;
        display: flex;
        justify-content: center;
        gap: 10px;
      }
      .new-item-input {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        width: 250px;
      }
      .new-item-button {
        padding: 10px 20px;
        background-color: #4caf50;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s ease;
      }
      .new-item-button:hover {
        background-color: #45a049;
      }
      /* Bid Page */
      .bid-page {
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
      }
      .back-button {
        background: none;
        border: none;
        color: #007bff;
        cursor: pointer;
        margin-bottom: 10px;
        font-size: 16px;
        transition: color 0.3s ease;
      }
      .back-button:hover {
        color: #0056b3;
      }
      .bid-title {
        text-align: center;
        margin-bottom: 20px;
        color: #333;
      }
      /* BidForm */
      .bid-form {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin-bottom: 20px;
      }
      .bid-input {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        width: 300px;
      }
      .bid-button {
        padding: 10px 20px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s ease;
      }
      .bid-button:hover {
        background-color: #0056b3;
      }
      /* BidList */
      .bid-list {
        margin-top: 20px;
      }
      .bid-item {
        padding: 10px;
        border-bottom: 1px solid #ddd;
      }
    `;
    document.head.appendChild(style);
    return () => {
      document.head.removeChild(style);
    };
  }, []);

  return (
    <div className="app-container">
      <Navbar refresh={fetchBids} />
      <div className="content-container">
        {!selectedItem ? (
          <>
            <h1 className="page-title">Menu</h1>
            <div className="menu-grid">
              {menuItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedItem(item)}
                  className="menu-item-card"
                >
                  {item.name}
                </div>
              ))}
            </div>
            <div className="new-item-container">
              <input
                type="text"
                placeholder="Enter new item"
                value={newItem}
                onChange={(e) => setNewItem(e.target.value)}
                className="new-item-input"
              />
              <button onClick={addNewItem} className="new-item-button">
                Add Item
              </button>
            </div>
          </>
        ) : (
          <div className="bid-page">
            <button onClick={() => setSelectedItem(null)} className="back-button">
              &larr; Back to Menu
            </button>
            <h2 className="bid-title">Bidding for {selectedItem.name}</h2>
            <BidForm fetchBids={fetchBids} selectedItem={selectedItem} />
            <BidList bids={bids} selectedItem={selectedItem} />
          </div>
        )}
      </div>
    </div>
  );
}

// Render the App into the root element
ReactDOM.render(<App />, document.getElementById("root"));
