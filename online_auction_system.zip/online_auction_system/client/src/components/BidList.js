import React from "react";
import { deleteBid, updateBid } from "../services/bidService";

function BidList({ bids, fetchBids }) {
  const handleDelete = async (id) => {
    const response = await deleteBid(id);
    if (response.data.success) {
      fetchBids();
    }
  };

  const handleUpdate = async (id, newBid) => {
    const response = await updateBid(id, newBid);
    if (response.data.success) {
      fetchBids();
    }
  };

  const handleIncrease = async (id, currentBid) => {
    const newBid = parseFloat(currentBid) + 1;
    const response = await updateBid(id, newBid);
    if (response.data.success) {
      fetchBids();
    }
  };

  return (
    <>
      {/* Embedded Creative Modern CSS */}
      <style>{`
        :root {
          --primary-color: #4a90e2;
          --primary-dark: #3a78c2;
          --background-color: #f5f7fa;
          --card-bg: #ffffff;
          --text-color: #333333;
          --border-color: #e0e0e0;
          --danger-color: #e74c3c;
          --danger-dark: #c0392b;
          --success-color: #2ecc71;
          --success-dark: #27ae60;
          --transition-speed: 0.3s;
        }

        body {
          margin: 0;
          font-family: 'Roboto', sans-serif;
          background-color: var(--background-color);
        }

        .table-container {
          max-width: 900px;
          margin: 40px auto;
          padding: 20px;
          background: linear-gradient(135deg, #fefefe, #f9f9f9);
          border-radius: 12px;
          box-shadow: 0 8px 16px rgba(0,0,0,0.1);
          overflow-x: auto;
          animation: fadeIn 0.8s ease-out;
        }

        h2 {
          text-align: center;
          margin-bottom: 20px;
          color: var(--text-color);
          font-size: 1.8rem;
          font-family: 'Montserrat', sans-serif;
        }

        table {
          width: 100%;
          border-collapse: collapse;
          font-size: 1rem;
          text-align: left;
          min-width: 500px;
        }

        th, td {
          padding: 12px 16px;
          border-bottom: 1px solid var(--border-color);
        }

        th {
          background: var(--primary-color);
          color: #fff;
          font-weight: 600;
        }

        tr:nth-child(even) {
          background-color: #f9f9f9;
        }

        tr:hover {
          background-color: #eef2f7;
        }

        input[type="number"] {
          width: 80px;
          padding: 8px;
          border: 1px solid var(--border-color);
          border-radius: 6px;
          font-size: 1rem;
          transition: border var(--transition-speed);
        }

        input[type="number"]:focus {
          border-color: var(--primary-color);
          outline: none;
        }

        .delete-btn, .increase-btn {
          border: none;
          padding: 8px 12px;
          border-radius: 6px;
          font-size: 1rem;
          cursor: pointer;
          transition: background-color var(--transition-speed);
          margin-right: 5px;
        }

        .delete-btn {
          background-color: var(--danger-color);
          color: #fff;
        }

        .delete-btn:hover {
          background-color: var(--danger-dark);
        }

        .increase-btn {
          background-color: var(--success-color);
          color: #fff;
        }

        .increase-btn:hover {
          background-color: var(--success-dark);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
          .table-container {
            margin: 20px;
            padding: 15px;
          }

          table {
            font-size: 0.9rem;
          }

          th, td {
            padding: 10px;
          }

          input[type="number"] {
            width: 60px;
            font-size: 0.9rem;
          }

          .delete-btn, .increase-btn {
            padding: 6px 10px;
            font-size: 0.9rem;
          }
        }

        @media (max-width: 480px) {
          .table-container {
            margin: 15px;
            padding: 10px;
          }

          table {
            font-size: 0.85rem;
          }

          th, td {
            padding: 8px;
          }

          input[type="number"] {
            width: 50px;
            font-size: 0.85rem;
          }

          .delete-btn, .increase-btn {
            padding: 5px 8px;
            font-size: 0.85rem;
          }
        }

        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(-20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>

      <div className="table-container">
        <h2>Bid Overview</h2>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Bid</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {bids.map((bid, i) => (
              <tr key={i}>
                <td>{bid.name}</td>
                <td>
                  <input
                    type="number"
                    value={bid.currentBid}
                    onChange={(e) => handleUpdate(bid._id, e.target.value)}
                  />
                </td>
                <td>
                  <button
                    className="increase-btn"
                    onClick={() => handleIncrease(bid._id, bid.currentBid)}
                  >
                    Increase
                  </button>
                  <button
                    className="delete-btn"
                    onClick={() => handleDelete(bid._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default BidList;
