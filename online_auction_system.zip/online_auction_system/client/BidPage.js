import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import BidForm from "./BidForm";
import BidList from "./BidList";
import { getBids } from "../services/bidService";

import "./Bidpage.css"

function BidPage() {
  const { itemId } = useParams();
  const [bids, setBids] = useState([]);

  const fetchBids = async () => {
    const response = await getBids();
    if (response.data.success) {
      setBids(response.data.data);
    }
  };

  useEffect(() => {
    fetchBids();
  }, []);

  return (
    <div>
      <h2>Bidding for Item {itemId}</h2>
      <BidForm fetchBids={fetchBids} selectedItemId={itemId} />
      <BidList bids={bids} fetchBids={fetchBids} selectedItemId={itemId} />
    </div>
  );
}

export default BidPage;
